package com.comcast.rphy.rlcmservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RlcmServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RlcmServicesApplication.class, args);
	}
}
