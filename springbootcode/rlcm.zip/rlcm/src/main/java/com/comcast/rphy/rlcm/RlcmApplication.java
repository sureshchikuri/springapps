package com.comcast.rphy.rlcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RlcmApplication {

	public static void main(String[] args) {
		SpringApplication.run(RlcmApplication.class, args);
	}
}
